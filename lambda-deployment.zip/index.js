import express from "express";
class RDG {
    constructor() {
        this.c = 1;
        this.s0 = 0;
        this.s1 = 0;
        this.s2 = 0;
        this.n = 0xefc8249d;
        this.rngCounter = 0;
        this.rngOffset = 0;
        this.rngSeedOverride = "";
        this.rngSeed = "";
    }
    init_builder(seeds) {
        this.c = 1;
        this.s0 = 0;
        this.s1 = 0;
        this.s2 = 0;
        this.n = 0;
        this.sow([(Date.now() * Math.random()).toString()]);
        if (seeds)
            this.init(seeds);
    }
    init(seeds) {
        if (typeof seeds === "string") {
            this.state(seeds);
        }
        else {
            this.sow(seeds);
        }
    }
    hash(data) {
        let h = undefined;
        let n = this.n;
        data = data.toString();
        for (let i = 0; i < data.length; i++) {
            n += data.charCodeAt(i);
            let t = 0.02519603282416938 * n;
            n = t >>> 0;
            t -= n;
            t *= n;
            n = t >>> 0;
            t -= n;
            n += t * 0x100000000;
            h = (n >>> 0) * 2.3283064365386963e-10;
        }
        this.n = n;
        return (h ?? 0);
    }
    sow(seeds) {
        this.n = 0xefc8249d;
        this.s0 = this.hash(" ");
        this.s1 = this.hash(" ");
        this.s2 = this.hash(" ");
        this.c = 1;
        if (!seeds)
            return;
        for (let i = 0; i < seeds.length && (seeds[i] != null); i++) {
            const seed = seeds[i].toString();
            this.s0 -= this.hash(seed);
            this.s0 += ~~(this.s0 < 0);
            this.s1 -= this.hash(seed);
            this.s1 += ~~(this.s1 < 0);
            this.s2 -= this.hash(seed);
            this.s2 += ~~(this.s2 < 0);
        }
    }
    rnd() {
        const t = 2091639 * this.s0 + this.c * 2.3283064365386963e-10;
        this.c = t | 0;
        this.s0 = this.s1;
        this.s1 = this.s2;
        this.s2 = t - this.c;
        return this.s2;
    }
    frac() {
        return this.rnd() + ((this.rnd() * 0x200000) | 0) * (1.1102230246251565e-16);
    }
    shuffle(array) {
        const a = array;
        for (let i = a.length - 1; i > 0; i--) {
            const r = Math.floor(this.frac() * (i + 1));
            const tmp = a[r];
            a[r] = a[i];
            a[i] = tmp;
        }
        return a;
    }
    shiftCharCodes(str, shiftCount) {
        const s = shiftCount ?? 0;
        let out = "";
        for (let i = 0; i < str.length; i++) {
            const cc = str.charCodeAt(i);
            out += String.fromCharCode(cc + s);
        }
        return out;
    }
    state(st) {
        return ['!rnd', this.c, this.s0, this.s1, this.s2].join(',');
    }
    executeWithSeedOffset(f, offset, seedOverride) {
        const tempRngCounter = this.rngCounter;
        const tempRngOffset = this.rngOffset;
        const tempRngSeedOverride = this.rngSeedOverride;
        const state = this.state();
        this.sow([this.shiftCharCodes((seedOverride || this.rngSeed), offset)]);
        this.rngCounter = 0;
        this.rngOffset = offset;
        this.rngSeedOverride = seedOverride || "";
        const returnValue = f();
        this.init(state);
        this.rngCounter = tempRngCounter;
        this.rngOffset = tempRngOffset;
        this.rngSeedOverride = tempRngSeedOverride;
        return returnValue;
    }
}
const LegendaryData = [
    ["Mewtwo", "mewtwo"],
    ["Lugia", "lugia"],
    ["Ho-oh", "ho-oh"],
    ["Kyogre", "kyogre"],
    ["Groudon", "groudon"],
    ["Rayquaza", "rayquaza"],
    ["Dialga", "dialga"],
    ["Palkia", "palkia"],
    ["Regigigas", "regigigas"],
    ["Giratina", "giratina-altered"],
    ["Arceus", "arceus"],
    ["Reshiram", "reshiram"],
    ["Zekrom", "zekrom"],
    ["Kyurem", "kyurem"],
    ["Xerneas", "xerneas"],
    ["Yveltal", "yveltal"],
    ["Zygarde", "zygarde-50"],
    ["Cosmog", "cosmog"],
    ["Necrozma", "necrozma"],
    ["Zacian", "zacian"],
    ["Zamazenta", "zamazenta"],
    ["Calyrex", "calyrex"],
    ["Koraidon", "koraidon"],
    ["Miraidon", "miraidon"],
    ["Terapagos", "terapagos"],
];
const LEGENDARIES = LegendaryData.map(d => d[0]);
const LEGENDARY_IDS = LegendaryData.map(d => d[1]);
const rdg = new RDG();
rdg.init_builder();
const DAY_MS = 86400000;
const SEED = "1073741824";
function getLegendaryGachaForTimestamp(ts) {
    const date = (ts instanceof Date) ? ts : new Date(ts);
    const dayCount = Math.floor(date.getTime() / DAY_MS);
    const offset = Math.floor(dayCount / LEGENDARIES.length);
    const index = dayCount % LEGENDARIES.length;
    const pick = rdg.executeWithSeedOffset(() => {
        const shuffled = rdg.shuffle(LEGENDARIES.slice());
        return shuffled[index];
    }, offset, SEED);
    const idx = LEGENDARIES.indexOf(pick);
    return { name: LEGENDARIES[idx], id: LEGENDARY_IDS[idx] };
}
function getMonthCalendar(year, monthZeroBased) {
    const first = new Date(Date.UTC(year, monthZeroBased, 1, 0, 0, 0));
    const res = [];
    let d = new Date(first.getTime());
    while (d.getUTCMonth() === monthZeroBased) {
        const leg = getLegendaryGachaForTimestamp(d);
        res.push({
            yyyy: d.getUTCFullYear(),
            mm: d.getUTCMonth() + 1,
            dd: d.getUTCDate(),
            dow: d.getUTCDay(),
            legendary: leg
        });
        d = new Date(d.getTime() + DAY_MS);
    }
    return res;
}
const app = express();
// Add CORS middleware
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
    }
    else {
        next();
    }
});
// Strip /default prefix for cleaner routing
app.use((req, res, next) => {
    if (req.url.startsWith('/default')) {
        req.url = req.url.replace('/default', '');
    }
    next();
});
app.get("/api/today", (_req, res) => {
    const now = new Date();
    const todayUTC = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    const leg = getLegendaryGachaForTimestamp(todayUTC);
    res.json({ date: todayUTC.toISOString().slice(0, 10), legendary: leg });
});
app.get("/api/tomorrow", (_req, res) => {
    const now = new Date();
    const tomorrowUTC = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
    const leg = getLegendaryGachaForTimestamp(tomorrowUTC);
    res.json({ date: tomorrowUTC.toISOString().slice(0, 10), legendary: leg });
});
app.get("/api/legendary", (req, res) => {
    const q = req.query.timestamp;
    const t = q ? new Date(q) : new Date();
    const dayUTC = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate()));
    const leg = getLegendaryGachaForTimestamp(dayUTC);
    res.json({ date: dayUTC.toISOString().slice(0, 10), legendary: leg });
});
app.get("/api/calendar", (req, res) => {
    const year = parseInt(req.query.year || "");
    const month = parseInt(req.query.month || "");
    if (Number.isNaN(year) || Number.isNaN(month)) {
        res.status(400).json({ error: "year and month required. month is 1-12." });
        return;
    }
    const cal = getMonthCalendar(year, month - 1);
    res.json({ year, month, days: cal });
});
// Export app for Lambda
export default app;
// Export functions for potential direct Lambda usage
export { getLegendaryGachaForTimestamp, getMonthCalendar };
import url from "url";
const __filename = url.fileURLToPath(import.meta.url);
const __dirname = url.fileURLToPath(new URL(".", import.meta.url));
if (process.argv[1] === __filename) {
    const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    if (process.argv[2] === "test-today") {
        const now = new Date();
        const todayUTC = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
        console.log(getLegendaryGachaForTimestamp(todayUTC));
    }
    else {
        app.listen(PORT, () => {
            console.log(`Server running locally at http://localhost:${PORT}`);
        });
    }
}
